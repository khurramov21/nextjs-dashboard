import React from 'react'

const  Customers= () => {
  return (
    <div>
      Customer
    </div>
  )
}

export default Customers
